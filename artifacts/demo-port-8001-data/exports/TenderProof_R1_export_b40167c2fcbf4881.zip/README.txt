TenderProof review package
Open the HTML file and print to PDF if needed. CSV contains line items. JSON contains immutable revision data, evidence coordinates, reference data and assumptions. RFQ is a draft and has not been sent. The source PDF is included.
